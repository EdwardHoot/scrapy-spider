#encoding: utf-8
import scrapy
import re
import uuid
import datetime
from scrapy.selector import Selector
from news.items import GenericItem
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider,Rule
from scrapy.http import Request
import logging

class AdhocSpider(CrawlSpider):
    name='adhoc'

    def start_requests(self):
        keywords=(
        )
        requests = []
        for keyword in keywords:
            for i in range(751)[::50]:
                request = Request('http://news.baidu.com/ns?word='+keyword+'&cl=2&ct=0&tn=news&rn=50&ie=utf-8&bt=0&et=0&pn='+ str(i), callback=self.parse_page)
                requests.append(request)
        return requests

    def printcn(uni):
        for i in uni:
            print uni.encode('utf-8')

    def parse_page(self,response):
        news=response.xpath('//div[@class="result"]')
        logging.info('************' + response.url + '**************')
        for p in news:
            author = p.xpath('div/p/text()').extract()
            link=''.join(p.xpath('h3/a/@href').extract())
            source=''.join(author)[:-19]
            date=''.join(''.join(author)[-17:]).replace(u'年',u'').replace(u'月',u'').replace(u'日',u'').replace(u':',u'').replace(u' ',u'').strip()+'00'
            yield Request(link, callback=lambda response, source_=source,date_=date: self.parse_news(response,source_,date_))

    def parse_news(self,response,source_,date_):
        item = GenericItem()
        self.get_id(response,item)
        self.get_url(response,item)
        item['source']=source_
        self.get_title(response,item)
        item['date'] = date_
        self.get_body(response,item)
        #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!remenber to Retrun Item after parse
        if item['body']:
            return item

    def get_id(self,response,item):
        id=uuid.uuid4()
        if id:
            item['id']=id
    def get_url(self,response,item):
        news_url=response.url
        if news_url:
            item['url']=news_url
    def get_title(self,response,item):
        title=response.xpath('//title/text()').extract()
        if title:
            item['title']=''.join(title).strip()
    def get_body(self,response,item):
        paras = response.xpath('//p | //span')
        news_body = ''
        for p in paras:
            data = p.xpath('string(.)').extract()
            if data:
                body = ''
                for line in ''.join(data).splitlines():
                    #   print entry.encode('utf-8')
                    body += line.strip()
                news_body += body + '_|_'
        item['body'] = news_body.replace('_|__|_','_|_')
